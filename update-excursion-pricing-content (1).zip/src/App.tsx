import { useState } from "react";
import { cn } from "./utils/cn";

/* ────────────────────────────────────────────
   DATA
   ──────────────────────────────────────────── */

const quickChips = [
  { label: "Orange Bay 25$", color: "bg-emerald-500" },
  { label: "Paradise 22$", color: "bg-sky-500" },
  { label: "Каир 55$", color: "bg-amber-500" },
  { label: "Луксор 60$", color: "bg-amber-600" },
  { label: "Квадроциклы 18$", color: "bg-rose-500" },
];

interface TourCard {
  icon: string;
  iconBg: string;
  title: string;
  time: string;
  features: string[];
  price: string;
  note?: string;
}

const tours: TourCard[] = [
  {
    icon: "🏖️",
    iconBg: "bg-emerald-100",
    title: "Orange Bay на яхте",
    time: "08:00–17:00",
    features: ["✅ Подходит для семей", "✅ Эко сбор включен"],
    price: "25$ взрослый / 15$ ребенок",
  },
  {
    icon: "🏝️",
    iconBg: "bg-sky-100",
    title: "Paradise Island",
    time: "08:30–16:30",
    features: ["✅ Самый бюджетный морской вариант", "✅ Эко сбор включен"],
    price: "22$ взрослый / 12$ ребенок",
  },
  {
    icon: "🕌",
    iconBg: "bg-amber-100",
    title: "Каир автобусом",
    time: "04:00–22:30",
    features: ["⚠️ Длинная дорога", "✅ Эко сбор включен"],
    price: "55$ взрослый / 35$ ребенок",
    note: "Нужна предоплата",
  },
  {
    icon: "🏛️",
    iconBg: "bg-amber-100",
    title: "Луксор",
    time: "03:30–21:00",
    features: ["✅ Лучший исторический маршрут", "✅ Эко сбор включен"],
    price: "60$ взрослый / 40$ ребенок",
    note: "Нужна предоплата",
  },
  {
    icon: "🏍️",
    iconBg: "bg-rose-100",
    title: "Сафари на квадроциклах",
    time: "15:00–20:00",
    features: ["✅ На закате", "✅ Эко сбор включен"],
    price: "18$ взрослый / 12$ ребенок",
  },
  {
    icon: "🤿",
    iconBg: "bg-rose-100",
    title: "Дайвинг для новичков",
    time: "09:00–15:00",
    features: ["✅ Без опыта", "✅ Эко сбор включен"],
    price: "35$ взрослый",
  },
  {
    icon: "🐠",
    iconBg: "bg-purple-100",
    title: "Батискаф",
    time: "1 час",
    features: ["✅ Идеально для маленьких детей", "✅ Эко сбор включен"],
    price: "20$ взрослый / 12$ ребенок",
  },
  {
    icon: "🛥️",
    iconBg: "bg-gray-100",
    title: "Индивидуальная яхта",
    time: "На 6 человек",
    features: ["✅ Без группы", "✅ Эко сбор включен"],
    price: "от 150$ на всю яхту",
  },
];

interface FaqItem {
  q: string;
  a: string;
}

const faqs: FaqItem[] = [
  {
    q: "❓ Эко сбор уже включен в цену?",
    a: "Да. Все цены на сайте уже полностью включают эко сбор 5$. Никаких дополнительных платежей на месте не будет. Это главное отличие нас от всех остальных.",
  },
  {
    q: "❓ Сколько стоит Orange Bay?",
    a: "25$ взрослый, 15$ ребенок. Трансфер и эко сбор полностью включены. Какой отель и на какую дату хотите?",
  },
  {
    q: "❓ Сколько стоит Каир?",
    a: "55$ взрослый, 35$ ребенок. Все включено. На какую дату?",
  },
  {
    q: "❓ А у гида предложили 20$",
    a: "Скорее всего это цена без эко сбора. На месте он попросит еще 5$. У меня цена окончательная.",
  },
  {
    q: "❓ Нужна ли предоплата?",
    a: "Предоплата нужна только на Каир и Луксор. На все остальные экскурсии предоплаты нет.",
  },
];

const whatsappFaqs = [
  {
    q: "Сколько стоит Orange Bay?",
    a: "25$ взрослый, 15$ ребенок. Трансфер и эко сбор полностью включены. Какой отель и на какую дату хотите?",
  },
  {
    q: "Сколько стоит Каир?",
    a: "55$ взрослый, 35$ ребенок. Все включено. На какую дату?",
  },
  {
    q: "Эко сбор уже включен?",
    a: "Да абсолютно. Никаких дополнительных платежей на месте не будет.",
  },
  {
    q: "А у гида предложил 20$",
    a: "Скорее всего это цена без эко сбора. На месте он попросит еще 5$. У меня цена окончательная.",
  },
];

const comparisonHotel = [
  { excursion: "Orange Bay", us: "25$", hotel: "45–50$" },
  { excursion: "Каир", us: "55$", hotel: "90–110$" },
  { excursion: "Луксор", us: "60$", hotel: "100–120$" },
];

/* ────────────────────────────────────────────
   COMPONENTS
   ──────────────────────────────────────────── */

function FloatingWhatsApp() {
  return (
    <a
      href="https://wa.me/201000000000"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 flex items-center gap-3 rounded-full bg-green-500 px-5 py-3 text-white shadow-xl shadow-green-300/50 transition-all hover:scale-105 hover:bg-green-600 font-semibold text-sm sm:text-base"
    >
      <svg className="h-5 w-5 fill-white" viewBox="0 0 24 24">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
      </svg>
      WhatsApp
    </a>
  );
}

function SectionHeading({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 text-center">
      {children}
    </h2>
  );
}

function FaqSection() {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <section className="py-16 sm:py-20 bg-white" id="faq">
      <div className="mx-auto max-w-3xl px-4 sm:px-6">
        <SectionHeading>Часто задаваемые вопросы</SectionHeading>
        <p className="mt-3 text-center text-slate-500 text-sm sm:text-base">
          Быстрые ответы на популярные вопросы
        </p>
        <div className="mt-10 space-y-3">
          {faqs.map((f, i) => (
            <div
              key={i}
              className="rounded-2xl border border-slate-200 bg-slate-50 overflow-hidden transition-all"
            >
              <button
                className="flex w-full items-center justify-between px-5 py-4 text-left text-sm sm:text-base font-medium text-slate-800 cursor-pointer hover:bg-slate-100"
                onClick={() => setOpen(open === i ? null : i)}
              >
                <span>{f.q}</span>
                <svg
                  className={cn(
                    "h-4 w-4 shrink-0 text-slate-400 transition-transform",
                    open === i && "rotate-180"
                  )}
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                  viewBox="0 0 24 24"
                >
                  <path d="M6 9l6 6 6-6" />
                </svg>
              </button>
              {open === i && (
                <div className="px-5 pb-4 text-sm text-slate-600 leading-relaxed">
                  {f.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ────────────────────────────────────────────
   APP
   ──────────────────────────────────────────── */

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-zinc-50 text-slate-800 font-sans antialiased">
      <FloatingWhatsApp />

      {/* ─── HERO ──────────────────────────── */}
      <header
        className="relative flex min-h-[85vh] items-center justify-center bg-cover bg-center px-4 py-20"
        style={{
          backgroundImage:
            'linear-gradient(to bottom, rgba(0,0,0,0.45), rgba(0,0,0,0.65)), url("https://images.pexels.com/photos/29095916/pexels-photo-29095916.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1600")',
        }}
      >
        <div className="relative z-10 mx-auto max-w-3xl text-center text-white">
          <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl drop-shadow-lg">
            Экскурсии в Хургаде
          </h1>
          <p className="mt-4 text-lg sm:text-xl text-white/90 drop-shadow">
            Прямые цены от организаторов • Без наценок отеля • Эко сбор включен
          </p>

          {/* Chips */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
            {quickChips.map((chip) => (
              <span
                key={chip.label}
                className={cn(
                  "inline-block rounded-full px-4 py-1.5 text-sm font-semibold text-white shadow-md",
                  chip.color
                )}
              >
                {chip.label}
              </span>
            ))}
          </div>

          {/* Eco collection badge */}
          <div className="mt-6 inline-flex items-center gap-2 rounded-xl bg-green-600/90 px-5 py-3 text-sm sm:text-base font-semibold text-white shadow-lg backdrop-blur-sm">
            <span className="text-xl">✅</span>
            Все цены уже включают эко сбор. Никаких дополнительных платежей на
            месте.
          </div>
        </div>
      </header>

      {/* ─── CATALOG ───────────────────────── */}
      <section className="py-16 sm:py-20" id="catalog">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <SectionHeading>
            Каталог экскурсий
          </SectionHeading>
          <p className="mt-2 text-center text-sm text-slate-500">
            Актуальные цены на июнь 2025 • Все цены окончательные
          </p>

          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {tours.map((t) => (
              <div
                key={t.title}
                className="flex flex-col rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-all hover:shadow-md hover:-translate-y-0.5"
              >
                <div
                  className={cn(
                    "mx-auto flex h-14 w-14 items-center justify-center rounded-xl text-2xl",
                    t.iconBg
                  )}
                >
                  {t.icon}
                </div>
                <h3 className="mt-4 text-center text-base font-bold text-slate-900">
                  {t.title}
                </h3>
                <p className="mt-1 text-center text-xs font-medium text-slate-400">
                  {t.time}
                </p>
                <ul className="mt-3 space-y-1 text-xs text-slate-600">
                  {t.features.map((f) => (
                    <li key={f}>{f}</li>
                  ))}
                </ul>
                <div className="mt-auto pt-4">
                  <p className="text-center text-lg font-extrabold text-indigo-600">
                    {t.price}
                  </p>
                  {t.note && (
                    <p className="mt-1 text-center text-xs font-medium text-amber-600">
                      ⚠️ {t.note}
                    </p>
                  )}
                  <div className="mt-3 flex gap-2">
                    <a
                      href="https://wa.me/201000000000"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 rounded-lg bg-green-500 px-3 py-2 text-center text-xs font-semibold text-white transition-colors hover:bg-green-600"
                    >
                      Узнать даты
                    </a>
                    <a
                      href="#faq"
                      className="flex-1 rounded-lg border border-slate-200 px-3 py-2 text-center text-xs font-medium text-slate-600 transition-colors hover:bg-slate-50"
                    >
                      Программа
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── COMPARISON ────────────────────── */}
      <section className="py-16 sm:py-20 bg-slate-50">
        <div className="mx-auto max-w-3xl px-4 sm:px-6">
          <SectionHeading>
            Сравнение с отельным гидом
          </SectionHeading>
          <p className="mt-2 text-center text-sm text-slate-500">
            Те же экскурсии — без переплат
          </p>

          <div className="mt-10 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="bg-indigo-50 text-xs font-semibold uppercase tracking-wider text-indigo-700">
                  <th className="px-5 py-3">Экскурсия</th>
                  <th className="px-5 py-3">Наша цена</th>
                  <th className="px-5 py-3">Отельный гид</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {comparisonHotel.map((row) => (
                  <tr key={row.excursion} className="hover:bg-slate-50">
                    <td className="px-5 py-3 font-medium text-slate-800">
                      {row.excursion}
                    </td>
                    <td className="px-5 py-3 font-bold text-green-600">
                      {row.us}
                    </td>
                    <td className="px-5 py-3 text-rose-500 font-medium">
                      {row.hotel}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <p className="mt-5 text-center text-sm text-slate-600 leading-relaxed">
            Средняя наценка отельного гида в Хургаде в этом сезоне 35–55%.
            Отельный гид сейчас продает Orange Bay за 45–50$. У нас 25$. Та же
            самая точно экскурсия, тот же самый автобус, тот же самый остров.
          </p>
        </div>
      </section>

      {/* ─── WHATSAPP TEMPLATES ────────────── */}
      <section className="py-16 sm:py-20 bg-white">
        <div className="mx-auto max-w-3xl px-4 sm:px-6">
          <SectionHeading>
            Шаблонные ответы в WhatsApp
          </SectionHeading>
          <p className="mt-2 text-center text-sm text-slate-500">
            Готовые ответы на самые частые вопросы
          </p>

          <div className="mt-10 space-y-4">
            {whatsappFaqs.map((item, i) => (
              <div
                key={i}
                className="rounded-2xl border border-slate-200 bg-slate-50 p-4 sm:p-5"
              >
                <p className="text-xs font-semibold uppercase tracking-wide text-indigo-500">
                  Вопрос клиента
                </p>
                <p className="mt-1 text-sm font-medium text-slate-800">
                  {item.q}
                </p>
                <div className="mt-3 rounded-xl bg-green-50 px-4 py-3 border border-green-100">
                  <p className="text-xs font-semibold uppercase tracking-wide text-green-600">
                    Ваш ответ
                  </p>
                  <p className="mt-1 text-sm text-slate-700 leading-relaxed">
                    {item.a}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── FAQ ───────────────────────────── */}
      <FaqSection />

      {/* ─── CTA ───────────────────────────── */}
      <section className="py-16 sm:py-20 bg-gradient-to-br from-indigo-600 to-indigo-800 text-white">
        <div className="mx-auto max-w-2xl px-4 text-center sm:px-6">
          <h2 className="text-2xl sm:text-3xl font-bold">
            Готовы забронировать?
          </h2>
          <p className="mt-3 text-white/80 text-sm sm:text-base">
            Напишите в WhatsApp — отвечаем за 2 минуты. Все цены окончательные,
            эко сбор включен.
          </p>
          <a
            href="https://wa.me/201000000000"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-6 inline-flex items-center gap-2 rounded-full bg-green-500 px-8 py-4 text-lg font-bold text-white shadow-xl shadow-green-500/40 transition-all hover:scale-105 hover:bg-green-400"
          >
            <svg className="h-6 w-6 fill-white" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
            Написать в WhatsApp
          </a>
        </div>
      </section>

      {/* ─── FOOTER ────────────────────────── */}
      <footer className="bg-slate-900 py-8 text-center text-xs text-slate-400">
        <p>© 2025 Экскурсии в Хургаде. Все цены актуальны на июнь 2025.</p>
        <p className="mt-1">
          Цены могут измениться в высокий сезон (ноябрь–декабрь) на 3–5$.
        </p>
      </footer>
    </div>
  );
}
